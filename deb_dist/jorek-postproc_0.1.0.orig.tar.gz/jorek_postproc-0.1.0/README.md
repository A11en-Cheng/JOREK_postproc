# JOREK_postproc
This programme aims at postproc a JOREK output with various data processing methods and plotting measures.
